./git_setup.sh

cd ..

zip -r screwedoku.zip screwedoku;
mv screwedoku.zip screwedoku/;


echo ""
echo "Your zip file lives in screwedoku.zip"
